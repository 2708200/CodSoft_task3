package com.test;

import java.util.List;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;

public class Quiz {

    private List<Question> questions;
    private int score;
    private int questionIndex;
    private boolean timeUp;
    private Timer timer;

    public Quiz(List<Question> questions) {
        this.questions = questions;
        this.score = 0;
        this.questionIndex = 0;
    }

    public void start() {
        Scanner scanner = new Scanner(System.in);

        while (questionIndex < questions.size()) {
            displayQuestion(questions.get(questionIndex));

            // Start timer for the question
            timeUp = false;
            startTimer(10); // 10 seconds timer

            int userAnswer = getUserAnswer(scanner);
            timer.cancel();

            if (!timeUp && questions.get(questionIndex).isCorrectAnswer(userAnswer)) {
                score++;
            }

            questionIndex++;
        }

        displayResults();
        scanner.close();
    }

    private void displayQuestion(Question question) {
        System.out.println(question.getQuestionText());
        for (int i = 0; i < question.getOptions().size(); i++) {
            System.out.println((i + 1) + ": " + question.getOptions().get(i));
        }
    }

    private int getUserAnswer(Scanner scanner) {
        int userAnswer = -1;

        while (!timeUp && (userAnswer < 1 || userAnswer > 4)) {
            System.out.print("Enter your answer (1-4): ");
            if (scanner.hasNextInt()) {
                userAnswer = scanner.nextInt();
            } else {
                scanner.next(); // clear invalid input
            }
        }
        return userAnswer - 1;
    }

    private void startTimer(int seconds) {
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                timeUp = true;
                System.out.println("\nTime's up!");
            }
        }, seconds * 1000);
    }

    private void displayResults() {
        System.out.println("\nQuiz Completed!");
        System.out.println("Your score: " + score + " out of " + questions.size());
    }
}
